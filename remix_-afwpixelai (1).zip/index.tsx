import React, { useState, useRef, useEffect } from "react";
import { createRoot } from "react-dom/client";
import JSZip from "jszip";

// --- Configuration & Constants ---

const APP_CONFIG = {
  appName: "afwPixelAi",
  version: "1.4.5",
  msmeRegistration: "UDYAM-RJ-14-0018404",
  poweredBy: "Askforwrite Digital",
};

const PROMPT_TEMPLATES = {
  identity: "keep the same face and face direction reference image, maintain subject identity. Using the uploaded image of the young girl/boy, generate a hyper-realistic young girl photography portrait while keeping the young girl original face, expressions, and natural features completely unchanged.",
  lens: "keep the same face as reference image, hair style and face direction reference image, maintain subject identity. To create a portrait with a telephoto lens, use a focal length between 85mm and 200mm to compress features and achieve a pleasing background blur (bokeh).",
  restoration: "Professional high-end photo restoration, fix scratches, denoise, sharpen, color correct, maintain original details and face identity, hyper-realistic, 8k."
};

const EFFECTS_LIBRARY = [
  { 
    id: "restoration", 
    name: "AI Restoration", 
    desc: "Fix scratches, denoise, sharpen, and color correct.", 
    icon: "fa-wand-magic-sparkles",
    type: "utility"
  },
  { 
    id: "cyberpunk", 
    name: "Cyberpunk City", 
    desc: "Futuristic neon lights, high-tech city background, cyberpunk fashion.", 
    icon: "fa-robot",
    type: "artistic"
  },
  { 
    id: "pencil_sketch", 
    name: "Pencil Sketch", 
    desc: "Detailed graphite pencil sketch on textured paper.", 
    icon: "fa-pencil",
    type: "artistic"
  },
  { 
    id: "watercolor", 
    name: "Watercolor Art", 
    desc: "Soft watercolor painting with pastel tones and artistic drips.", 
    icon: "fa-brush",
    type: "artistic"
  },
  { 
    id: "oil_painting", 
    name: "Oil Painting", 
    desc: "Classic oil painting style with visible brush strokes and rich colors.", 
    icon: "fa-palette",
    type: "artistic"
  },
  { 
    id: "venetian", 
    name: "Venetian Red", 
    desc: "Venetian red dress, white lace, ancient oak tree, golden hour.", 
    icon: "fa-tree",
    type: "artistic"
  },
  { 
    id: "golden_meadow", 
    name: "Golden Meadow", 
    desc: "Playfully running through a multicolored meadow at sunset.", 
    icon: "fa-sun",
    type: "artistic"
  },
  { 
    id: "summer_wildflower", 
    name: "Wildflower Bliss", 
    desc: "Standing amidst a kaleidoscope of wildflowers, arms wide, basking in golden light.", 
    icon: "fa-leaf", 
    type: "artistic" 
  },
  { 
    id: "rembrandt", 
    name: "Rembrandt", 
    desc: "Dramatic shadows, traditional folk attire, Prussian blue background.", 
    icon: "fa-palette",
    type: "artistic"
  },
  { 
    id: "chalkboard", 
    name: "Chalkboard", 
    desc: "Red leotard against a dark chalkboard backdrop.", 
    icon: "fa-star",
    type: "artistic"
  },
  { 
    id: "weightless_leap", 
    name: "Weightless Leap", 
    desc: "Ballerina performing a stunning leap, concentrate expression, light playing off the tutu.", 
    icon: "fa-person-running", 
    type: "artistic" 
  },
  { 
    id: "flamenco", 
    name: "Flamenco Swirl", 
    desc: "Young dancer with hair flowing and flamenco-inspired red and black dress.", 
    icon: "fa-fan", 
    type: "artistic" 
  },
  { 
    id: "rainbow_tutu", 
    name: "Rainbow Tutu", 
    desc: "Joyful dancer in a rainbow-hued tutu dress under warm lighting.", 
    icon: "fa-child-reaching",
    type: "artistic"
  },
  { 
    id: "dandelion", 
    name: "Dandelion", 
    desc: "Twirling in a meadow with a rainbow tutu and floating dandelions.", 
    icon: "fa-wind", 
    type: "artistic" 
  },
  { 
    id: "springtime", 
    name: "Springtime", 
    desc: "Arms up in a field of blooming flowers, bright floral dress.", 
    icon: "fa-seedling", 
    type: "artistic" 
  },
  { 
    id: "water_park", 
    name: "Water Park", 
    desc: "Red dress playing in splashing water, droplets sparkling.", 
    icon: "fa-water",
    type: "artistic"
  },
  { 
    id: "bokeh_water", 
    name: "Bokeh Magic", 
    desc: "Playing in water, droplets as sparkling highlights against a soft bokeh background.", 
    icon: "fa-droplet", 
    type: "artistic" 
  },
  { 
    id: "playground_slide", 
    name: "Playground Slide", 
    desc: "Orange jacket sliding down a vividly painted slide.", 
    icon: "fa-play", 
    type: "artistic" 
  },
  { 
    id: "kite_beach", 
    name: "Kite Beach", 
    desc: "On soft sand flying a vibrant kite under a clear sky.", 
    icon: "fa-umbrella-beach", 
    type: "artistic" 
  },
  { 
    id: "carousel", 
    name: "Carousel Joy", 
    desc: "Perched atop an ornately decorated carousel horse.", 
    icon: "fa-horse-head", 
    type: "artistic" 
  },
  { 
    id: "meadow_dance", 
    name: "Meadow Dance", 
    desc: "Dancing in a tranquil meadow bathed in golden sunlight.", 
    icon: "fa-music", 
    type: "artistic" 
  },
  { 
    id: "forest_run", 
    name: "Forest Run", 
    desc: "Running through a sun-dappled path in lush greenery.", 
    icon: "fa-person-hiking", 
    type: "artistic" 
  },
  { 
    id: "butterfly_lamp", 
    name: "Butterfly Lamp", 
    desc: "In a tutu gazing at a lamp post attracting a magnificent butterfly.", 
    icon: "fa-bug", 
    type: "artistic" 
  },
  { 
    id: "magic_umbrella", 
    name: "Magic Umbrella", 
    desc: "Under an umbrella in a golden glow with whimsical butterflies and sparkling particles.", 
    icon: "fa-umbrella", 
    type: "artistic" 
  },
  { 
    id: "fairytale_creature", 
    name: "Fairytale", 
    desc: "Whimsical creature resting against an old-fashioned lamppost.", 
    icon: "fa-dragon", 
    type: "artistic" 
  },
  { 
    id: "firefly", 
    name: "Firefly Twilight", 
    desc: "Holding a jar of fireflies in an ethereal twilight glow.", 
    icon: "fa-lightbulb",
    type: "artistic"
  },
  { 
    id: "christmas", 
    name: "Christmas", 
    desc: "Opening a magical present with golden sparkles spilling out.", 
    icon: "fa-gift", 
    type: "artistic" 
  },
  { 
    id: "toy_village", 
    name: "Toy Village", 
    desc: "Exploring a tiny toy village on a table in a lush garden at sunset.", 
    icon: "fa-house-chimney", 
    type: "artistic" 
  },
  { 
    id: "ribbon_dance", 
    name: "Ribbon Dance", 
    desc: "Dancing with colorful ribbons in a sunlit park.", 
    icon: "fa-ribbon", 
    type: "artistic" 
  },
  { 
    id: "sandcastle", 
    name: "Sandcastle", 
    desc: "Absorbed in constructing an elaborate sandcastle.", 
    icon: "fa-trowel-bricks", 
    type: "artistic" 
  },
  { 
    id: "candlelight_pool", 
    name: "Candlelight", 
    desc: "By a tranquil pool with floating candles, lily pads, and starfish.", 
    icon: "fa-fire-flame-curved", 
    type: "artistic" 
  },
  { 
    id: "lantern_festival", 
    name: "Lanterns", 
    desc: "Clutching a glowing lantern leading friends through a field.", 
    icon: "fa-paper-plane", 
    type: "artistic" 
  },
  { 
    id: "feathered", 
    name: "Feathered", 
    desc: "In colorful cultural attire with intricate patterns and feathers.", 
    icon: "fa-feather", 
    type: "artistic" 
  },
  { 
    id: "wishful_birthday", 
    name: "Birthday", 
    desc: "Leaning over a cake with numerous glowing candles.", 
    icon: "fa-cake-candles", 
    type: "artistic" 
  }
];

// --- AI Service ---

const generateAiImage = async (originalBase64: string, effectId: string): Promise<string> => {
  const effect = EFFECTS_LIBRARY.find(e => e.id === effectId);
  if (!effect) throw new Error("Effect not found");

  let finalPrompt = "";
  if (effect.id === "restoration") {
    finalPrompt = PROMPT_TEMPLATES.restoration;
  } else {
    finalPrompt = `${PROMPT_TEMPLATES.identity} ${PROMPT_TEMPLATES.lens} Edit this image as follows: ${effect.desc}`;
  }

  const response = await fetch("/api/generate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      originalBase64,
      effectId,
      promptText: finalPrompt
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: "Server error occurred" }));
    throw new Error(errorData.error || `HTTP error ${response.status}`);
  }

  const data = await response.json();
  if (data.success && data.image) {
    return data.image;
  } else {
    throw new Error("Unable to retrieve generated image from server response.");
  }
};

// --- Components ---

const Logo = ({ customSrc }: { customSrc?: string | null }) => {
    const [hasError, setHasError] = useState(false);
    // Strictly use the assets path or custom upload
    const src = customSrc || "assets/logo.png";

    useEffect(() => {
        setHasError(false);
    }, [src]);

    return (
        <div className="w-12 h-12 rounded-xl bg-blue-950 flex items-center justify-center overflow-hidden shadow-lg border border-blue-900/50">
             {!hasError ? (
                 <img 
                    src={src} 
                    alt="afw Logo" 
                    className="w-full h-full object-contain"
                    onError={() => setHasError(true)}
                 />
             ) : (
                <span className="text-2xl font-serif italic font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-orange-500 via-red-500 to-yellow-500 pb-1">afw</span>
             )}
        </div>
    );
};

const Header = ({ customLogo }: { customLogo?: string | null }) => (
  <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 sticky top-0 z-50">
    <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Logo customSrc={customLogo} />
        <div>
          <h1 className="text-2xl font-bold tracking-tight leading-none">
             {/* Tech white for Pixel, Fire gradient for Ai */}
            <span className="text-slate-100">Pixel</span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 via-red-500 to-yellow-500">Ai</span>
          </h1>
          <span className="text-[10px] font-semibold text-slate-500 tracking-wider uppercase">
            Img Studio
          </span>
        </div>
      </div>
      <div className="hidden sm:flex items-center gap-4 text-xs font-medium text-slate-400">
        <span><i className="fa-solid fa-shield-halved mr-1 text-slate-600"></i>Identity Lock™</span>
        <span><i className="fa-solid fa-camera mr-1 text-slate-600"></i>Cinematic Lens</span>
      </div>
    </div>
  </header>
);

const Footer = () => (
  <footer className="bg-slate-950 text-slate-500 py-6 text-center text-xs mt-auto border-t border-slate-900">
    <p className="mb-2">
      <span className="font-semibold text-slate-400">Powered by {APP_CONFIG.poweredBy}</span>
    </p>
    <p className="opacity-60 font-mono">
      MSME Registered: {APP_CONFIG.msmeRegistration}
    </p>
    <div className="mt-4 flex justify-center gap-4 opacity-50">
      <i className="fa-brands fa-instagram hover:text-white cursor-pointer transition-colors"></i>
      <i className="fa-brands fa-twitter hover:text-white cursor-pointer transition-colors"></i>
      <i className="fa-solid fa-globe hover:text-white cursor-pointer transition-colors"></i>
    </div>
  </footer>
);

interface EffectCardProps {
  effect: any;
  isSelected: boolean;
  onClick: () => void;
}

const EffectCard: React.FC<EffectCardProps> = ({ effect, isSelected, onClick }) => (
  <button
    onClick={onClick}
    className={`
      flex flex-col items-center justify-center p-2 rounded-xl border transition-all duration-200 w-full aspect-square text-center group relative overflow-hidden
      ${isSelected 
        ? 'border-orange-500 bg-orange-900/20 shadow-md ring-1 ring-orange-500/50' 
        : 'border-slate-700 bg-slate-800 hover:border-slate-600 hover:bg-slate-700'
      }
    `}
    title={effect.desc}
  >
    <div className={`
      w-8 h-8 rounded-lg flex items-center justify-center mb-1 text-md transition-colors
      ${isSelected ? 'bg-orange-500 text-white' : 'bg-slate-700 text-slate-400 group-hover:bg-slate-600 group-hover:text-slate-200'}
    `}>
      <i className={`fa-solid ${effect.icon}`}></i>
    </div>
    <h3 className={`font-bold text-[10px] leading-tight line-clamp-2 ${isSelected ? 'text-slate-200' : 'text-slate-400 group-hover:text-slate-300'}`}>
      {effect.name}
    </h3>
  </button>
);

// --- Main App Component ---

const App = () => {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [selectedEffectId, setSelectedEffectId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLoadingDemo, setIsLoadingDemo] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isComparing, setIsComparing] = useState(false);
  
  const [customLogo, setCustomLogo] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Check for ZIP file
    if (file.name.endsWith('.zip') || file.type === 'application/zip' || file.type === 'application/x-zip-compressed') {
        setError(null);
        try {
            const zip = new JSZip();
            const contents = await zip.loadAsync(file);
            
            let foundLogo = false;
            let foundImage = false;
            
            // 1. Look for logo.png (insensitive)
            const fileNames = Object.keys(contents.files);
            const logoFileName = fileNames.find(name => name.toLowerCase().includes('logo.png') && !contents.files[name].dir);
            
            if (logoFileName) {
                const logoBlob = await contents.files[logoFileName].async('blob');
                const logoUrl = URL.createObjectURL(logoBlob);
                setCustomLogo(logoUrl);

                // --- DYNAMIC FAVICON UPDATE ---
                const iconLinks = document.querySelectorAll("link[rel*='icon']");
                iconLinks.forEach(link => (link as HTMLLinkElement).href = logoUrl);
                
                if (iconLinks.length === 0) {
                    const link = document.createElement('link');
                    link.rel = 'icon';
                    link.href = logoUrl;
                    document.head.appendChild(link);
                }
                
                foundLogo = true;
            }

            // 2. Look for the first valid image
            const validExtensions = ['.jpg', '.jpeg', '.png', '.webp'];
            const imageFileName = fileNames.find(name => {
                const lower = name.toLowerCase();
                const isImage = validExtensions.some(ext => lower.endsWith(ext));
                const isNotLogo = !lower.includes('logo.png');
                const isNotDir = !contents.files[name].dir;
                return isImage && isNotLogo && isNotDir;
            });

            if (imageFileName) {
                const imgBlob = await contents.files[imageFileName].async('blob');
                setOriginalImage(URL.createObjectURL(imgBlob));
                setResultImage(null);
                foundImage = true;
            }
            
            if (!foundLogo && !foundImage) {
                setError("ZIP file loaded but no valid images or logo.png found.");
            } else if (foundLogo && !foundImage) {
                setError(null);
            }

        } catch (err: any) {
            console.error("Zip Error:", err);
            setError("Failed to process ZIP file.");
        }
    } else {
        // Handle Standard Image
        const reader = new FileReader();
        reader.onload = (event) => {
          setOriginalImage(event.target?.result as string);
          setResultImage(null);
          setError(null);
        };
        reader.readAsDataURL(file);
    }
  };

  const handleDemoLoad = async () => {
    setIsLoadingDemo(true);
    setError(null);
    try {
        const response = await fetch("https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80");
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
            setOriginalImage(reader.result as string);
            setResultImage(null);
            setError(null);
            setIsLoadingDemo(false);
        }
        reader.readAsDataURL(blob);
    } catch (e) {
        setError("Failed to load demo image.");
        setIsLoadingDemo(false);
    }
  };

  const handleGenerate = async () => {
    if (!originalImage || !selectedEffectId) return;

    setIsGenerating(true);
    setError(null);
    
    try {
      const generated = await generateAiImage(originalImage, selectedEffectId);
      setResultImage(generated);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes('429') || err.message?.includes('quota') || err.message?.includes('RESOURCE_EXHAUSTED') || err.status === 429) {
          setError("QUOTA_EXCEEDED");
      } else {
          // Display generic error to user to avoid system-like error text
          setError("Failed to generate image. Please try again.");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (resultImage) {
      const link = document.createElement("a");
      link.href = resultImage;
      link.download = `afwPixelAi_${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleShare = async () => {
    if (!resultImage) return;

    const confirmed = window.confirm("Are you sure you want to share this image?");
    if (!confirmed) return;

    try {
        const base64Response = await fetch(resultImage);
        const blob = await base64Response.blob();
        const file = new File([blob], "afw_art.png", { type: "image/png" });

        if (navigator.share) {
            await navigator.share({
                title: 'Created with afwPixelAi',
                text: 'Check out this cinematic image created with afwPixelAi!',
                files: [file],
            });
        } else {
            // Fallback for desktop browsers that don't support file sharing via navigator.share
            alert("Native sharing is not supported on this device. You can download the image instead.");
        }
    } catch (err) {
        console.error("Share failed:", err);
    }
  };

  const startCompare = () => setIsComparing(true);
  const stopCompare = () => setIsComparing(false);

  const isWorkspace = !!originalImage;

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 font-sans text-slate-200 selection:bg-orange-500 selection:text-white">
      <Header customLogo={customLogo} />

      <main className="flex-1 max-w-5xl mx-auto w-full p-4 md:p-6 flex flex-col">
        
        {!isWorkspace ? (
          // --- Upload Screen ---
          <div className="flex-1 flex flex-col items-center justify-center py-12">
            <div className="text-center max-w-2xl">
              <h2 className="text-4xl md:text-5xl font-extrabold mb-6 tracking-tight">
                <span className="text-slate-100">Cinematic</span> <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 via-red-500 to-yellow-500">Image Effect</span>
              </h2>
              <p className="text-lg text-slate-400 mb-10 leading-relaxed">
                Transform ordinary photos into cinematic masterpieces while maintaining the true identity and expressions of your loved ones.
              </p>
              
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="
                  group relative overflow-hidden rounded-3xl bg-slate-900 border-4 border-dashed border-slate-800 
                  p-12 cursor-pointer transition-all hover:border-orange-500 hover:shadow-xl hover:shadow-orange-900/10 hover:-translate-y-1
                "
              >
                <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="relative z-10 flex flex-col items-center">
                  <div className="w-20 h-20 bg-slate-800 text-blue-500 rounded-full flex items-center justify-center text-3xl mb-6 group-hover:scale-110 group-hover:bg-slate-700 transition-all shadow-inner">
                    <i className="fa-solid fa-cloud-arrow-up"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-200 mb-2">Upload Photo or ZIP</h3>
                  <p className="text-slate-500">Supports images or .zip with logo.png</p>
                </div>
              </div>

              <div className="mt-6">
                  <button 
                    onClick={handleDemoLoad}
                    disabled={isLoadingDemo}
                    className="text-sm font-medium text-slate-500 hover:text-orange-400 transition-colors flex items-center justify-center gap-2 mx-auto disabled:opacity-50"
                  >
                    {isLoadingDemo ? (
                         <i className="fa-solid fa-circle-notch fa-spin"></i>
                    ) : (
                        <i className="fa-solid fa-image"></i>
                    )}
                    Try with Demo Photo
                  </button>
              </div>

              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*,.zip,application/zip,application/x-zip-compressed"
                onChange={handleFileUpload} 
              />
              
              <div className="mt-12 grid grid-cols-3 gap-6 opacity-60">
                <div className="flex flex-col items-center">
                  <i className="fa-solid fa-wand-magic-sparkles text-2xl mb-2 text-slate-600"></i>
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">90+ Effects</span>
                </div>
                <div className="flex flex-col items-center">
                  <i className="fa-solid fa-fingerprint text-2xl mb-2 text-slate-600"></i>
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Identity Safe</span>
                </div>
                <div className="flex flex-col items-center">
                  <i className="fa-solid fa-download text-2xl mb-2 text-slate-600"></i>
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">HD Export</span>
                </div>
              </div>
            </div>
            
            {error && (
                <div className="mt-6 p-3 bg-red-900/20 text-red-400 text-sm rounded-lg border border-red-900/50">
                    <i className="fa-solid fa-circle-exclamation mr-2"></i>{error}
                </div>
            )}
          </div>
        ) : (
          // --- Workspace Screen ---
          <div className="flex flex-col lg:flex-row gap-6 h-full">
            
            {/* Editor Canvas Area (Left) */}
            <div className="flex-1 flex flex-col gap-4">
              <div className="bg-slate-900 rounded-2xl shadow-lg border border-slate-800 overflow-hidden flex-1 relative min-h-[400px] flex items-center justify-center">
                
                {/* Image Container */}
                <div className="relative max-w-full max-h-full p-4 w-full h-full flex items-center justify-center bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]">
                   {/* If Result Exists, handle comparison */}
                   {resultImage ? (
                     <img 
                       src={isComparing ? originalImage : resultImage} 
                       alt="Workspace" 
                       className="max-w-full max-h-full object-contain shadow-2xl rounded-lg animate-fade-in"
                     />
                   ) : (
                     <img 
                       src={originalImage} 
                       alt="Original" 
                       className="max-w-full max-h-full object-contain shadow-xl rounded-lg"
                     />
                   )}

                   {/* Loading Overlay */}
                   {isGenerating && (
                     <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm z-20 flex flex-col items-center justify-center">
                       <div className="w-16 h-16 border-4 border-orange-900/50 border-t-orange-500 rounded-full animate-spin mb-4"></div>
                       <p className="text-slate-200 font-bold text-lg animate-pulse">Creating Masterpiece...</p>
                       <p className="text-slate-500 text-sm mt-1">Applying global identity lock</p>
                     </div>
                   )}
                </div>

                {/* Compare Overlay (Bottom Center of Canvas) */}
                {resultImage && !isGenerating && (
                   <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex items-center gap-3 z-10">
                    <button 
                      onMouseDown={startCompare}
                      onMouseUp={stopCompare}
                      onTouchStart={startCompare}
                      onTouchEnd={stopCompare}
                      className="bg-slate-950/90 text-white px-5 py-2.5 rounded-full font-medium text-sm backdrop-blur hover:bg-black transition shadow-lg active:scale-95 select-none border border-slate-800"
                    >
                      <i className="fa-solid fa-eye mr-2"></i>Hold to Compare
                    </button>
                  </div>
                )}
                 
                 {/* Reset Button (Top Right) */}
                 <button 
                    onClick={() => { setOriginalImage(null); setResultImage(null); }}
                    className="absolute top-4 right-4 bg-slate-800/80 p-2 rounded-full text-slate-400 hover:text-red-400 hover:bg-slate-800 transition shadow-sm z-10"
                    title="Close Image"
                 >
                    <i className="fa-solid fa-xmark"></i>
                 </button>
              </div>

              {/* ACTION BAR: Generate, Download, Share (Below Image) */}
              <div className="flex items-center gap-3">
                 <button
                    onClick={handleGenerate}
                    disabled={!selectedEffectId || isGenerating}
                    className={`
                      flex-1 py-4 rounded-xl font-bold text-lg shadow-lg transition-all transform active:scale-[0.98] flex items-center justify-center
                      ${!selectedEffectId || isGenerating
                        ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-slate-700'
                        : 'bg-gradient-to-r from-orange-500 to-pink-600 text-white hover:shadow-orange-900/50 hover:from-orange-600 hover:to-pink-700'
                      }
                    `}
                  >
                    {isGenerating ? (
                      <i className="fa-solid fa-circle-notch fa-spin"></i>
                    ) : (
                      <>
                        <i className="fa-solid fa-wand-magic-sparkles mr-2"></i>
                        {resultImage ? 'Regenerate Art' : 'Generate Art'}
                      </>
                    )}
                 </button>

                 <div className="flex gap-2">
                     <button
                        onClick={handleDownload}
                        disabled={!resultImage || isGenerating}
                        className={`
                          w-12 sm:w-auto sm:px-6 py-4 rounded-xl font-bold text-lg shadow-md transition-all flex items-center justify-center
                          ${!resultImage || isGenerating
                            ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-slate-700' 
                            : 'bg-slate-900 text-slate-200 border border-slate-700 hover:bg-slate-800 hover:text-orange-500 hover:border-orange-500/50'
                          }
                        `}
                        title="Download Image"
                     >
                       <i className="fa-solid fa-download sm:mr-2"></i>
                       <span className="hidden sm:inline">Download</span>
                     </button>
                     
                     <button
                        onClick={handleShare}
                        disabled={!resultImage || isGenerating}
                        className={`
                          w-12 sm:w-auto sm:px-6 py-4 rounded-xl font-bold text-lg shadow-md transition-all flex items-center justify-center
                          ${!resultImage || isGenerating
                            ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-slate-700' 
                            : 'bg-slate-900 text-slate-200 border border-slate-700 hover:bg-slate-800 hover:text-blue-400 hover:border-blue-500/50'
                          }
                        `}
                        title="Share Image"
                     >
                       <i className="fa-solid fa-share-nodes sm:mr-2"></i>
                       <span className="hidden sm:inline">Share</span>
                     </button>
                 </div>
              </div>

              {/* Error Message */}
              {error === "QUOTA_EXCEEDED" ? (
                  <div className="p-4 bg-red-900/20 border border-red-900/50 text-red-400 rounded-xl flex flex-col items-start gap-2 animate-shake">
                    <div className="flex items-center gap-2 font-bold">
                        <i className="fa-solid fa-triangle-exclamation text-lg"></i>
                        <span>Generation Failed: Quota Exceeded</span>
                    </div>
                    <p className="text-sm">You have exceeded your current API quota.</p>
                    <a 
                        href="https://aistudio.google.com/app/apikey" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="mt-2 bg-red-900/40 hover:bg-red-900/60 text-red-200 px-4 py-2 rounded-lg text-xs font-bold transition-colors border border-red-800"
                    >
                        Renew Quota / Get API Key
                    </a>
                  </div>
              ) : error && (
                <div className="p-4 bg-red-900/20 border border-red-900/50 text-red-400 rounded-xl flex items-center animate-shake">
                   <i className="fa-solid fa-triangle-exclamation mr-3 text-lg"></i>
                   <div>
                     <p className="font-bold text-sm">Generation Failed</p>
                     <p className="text-xs mt-1">{error}</p>
                   </div>
                </div>
              )}
            </div>

            {/* Tools Sidebar (Right) */}
            <div className="w-full lg:w-80 flex flex-col gap-4">
              <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 flex-1 flex flex-col shadow-lg">
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="font-bold text-slate-200">Select Effect</h3>
                  <span className="text-xs bg-orange-900/50 text-orange-400 px-2 py-1 rounded-full font-medium border border-orange-900">
                    {EFFECTS_LIBRARY.length}
                  </span>
                </div>

                {/* 3-Column Grid for Effects */}
                <div className="grid grid-cols-3 gap-2 overflow-y-auto pr-1 custom-scrollbar max-h-[500px] lg:max-h-[calc(100vh-250px)] content-start">
                  {EFFECTS_LIBRARY.map((effect) => (
                    <EffectCard 
                      key={effect.id}
                      effect={effect}
                      isSelected={selectedEffectId === effect.id}
                      onClick={() => setSelectedEffectId(effect.id)}
                    />
                  ))}
                </div>
              </div>
              
              {/* MSME Badge (Small) */}
              <div className="bg-slate-900 rounded-xl p-3 flex items-center justify-center gap-3 text-slate-500 text-xs font-mono border border-slate-800">
                 <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="India" className="h-6 opacity-40 grayscale" />
                 <div>
                   <div className="font-bold text-slate-400">ASKFORWRITE DIGITAL</div>
                   <div>{APP_CONFIG.msmeRegistration}</div>
                 </div>
              </div>
            </div>

          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

const root = createRoot(document.getElementById("root")!);
root.render(<App />);