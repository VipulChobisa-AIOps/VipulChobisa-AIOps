import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Set limit to 50MB to handle large base64 selfie payloads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Server-side Gemini API endpoint
  app.post("/api/generate", async (req, res) => {
    try {
      const { originalBase64, effectId, promptText } = req.body;

      if (!originalBase64) {
        return res.status(400).json({ error: "No image payload received." });
      }

      if (!promptText) {
        return res.status(400).json({ error: "No generation instructions provided." });
      }

      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      if (!apiKey) {
        return res.status(500).json({ 
          error: "Gemini API key is not configured. Please add your key in Settings > Secrets." 
        });
      }

      console.log(`Server-side: received request to apply effect '${effectId}'`);

      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          }
        }
      });

      // Extract base64 clean string and mime type
      let base64Data = originalBase64;
      let mimeType = "image/jpeg";

      if (originalBase64.includes(",")) {
        const parts = originalBase64.split(",");
        const header = parts[0];
        base64Data = parts[1];
        const match = header.match(/data:([^;]+);base64/);
        if (match) {
          mimeType = match[1];
        }
      }

      // Try multiple image models for maximum robustness (fallback chain)
      const modelsToTry = [
        "gemini-2.5-flash-image",
        "gemini-3.1-flash-image-preview",
        "gemini-3-pro-image-preview"
      ];

      let lastError: any = null;
      let generatedUrl: string | null = null;
      let usedModel: string | null = null;

      for (const modelName of modelsToTry) {
        try {
          console.log(`Server-side: attempting generation with ${modelName}...`);
          
          const response = await ai.models.generateContent({
            model: modelName,
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: mimeType,
                    data: base64Data
                  }
                },
                { text: promptText }
              ]
            }
          });

          const firstCandidate = response.candidates?.[0];
          if (!firstCandidate) {
            console.log(`[Warning] No candidates returned by ${modelName}. Response:`, JSON.stringify(response));
            throw new Error(`Model returned empty candidates.`);
          }

          console.log(`[Info] ${modelName} finish reason: ${firstCandidate.finishReason}`);

          const parts = firstCandidate.content?.parts;
          if (!parts || parts.length === 0) {
            console.log(`[Warning] Candidate content contains no parts.`);
            throw new Error(`Model candidate content has no parts.`);
          }

          // Search details for the returned image part
          let found = false;
          for (const part of parts) {
            if (part.inlineData) {
              const returnedMime = part.inlineData.mimeType || "image/jpeg";
              generatedUrl = `data:${returnedMime};base64,${part.inlineData.data}`;
              usedModel = modelName;
              found = true;
              break;
            }
          }

          if (found && generatedUrl) {
            console.log(`[Success] Successfully generated image with model ${modelName}!`);
            return res.json({ success: true, image: generatedUrl, model: modelName });
          }

          // Check if text was returned instead (some models might summarize or explain the failure)
          const textPart = parts.find(p => p.text);
          if (textPart) {
            console.warn(`[Warning] Model returned text instead of image:`, textPart.text);
            throw new Error(`Model returned text response instead of image: "${textPart.text}"`);
          }

          throw new Error("Response parts did not contain any valid inline image data.");
        } catch (error: any) {
          console.error(`Error with ${modelName}:`, error?.message || error);
          lastError = error;
        }
      }

      // If we depleted all models in the fallback chain
      const defaultMessage = "All image generation models failed to return content. This might be due to safety filters, prompt restrictions, or API quota limit.";
      const detailedMessage = lastError?.message || lastError?.statusText || defaultMessage;
      return res.status(500).json({ error: detailedMessage });

    } catch (err: any) {
      console.error("Unhandled error in server-side API:", err);
      return res.status(500).json({ error: err.message || "Failed to process image generation request." });
    }
  });

  // Hot Module Replacement (HMR) warning/setup integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Hosted with Vite middleware (development mode)");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Hosted with static assets (production mode)");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on host 0.0.0.0 and port ${PORT}`);
  });
}

startServer();
