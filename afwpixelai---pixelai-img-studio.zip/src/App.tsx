/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useDropzone } from 'react-dropzone';
import { 
  Upload, 
  Sparkles, 
  Download, 
  Share2, 
  RefreshCw, 
  Image as ImageIcon,
  AlertCircle,
  ArrowRight,
  History,
  Crown
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Header, Footer } from './components/Layout';
import { EffectCard } from './components/EffectCard';
import { SettingsModal, PaymentModal, StaticModal } from './components/Modals';
import { Effect, EFFECTS_LIBRARY, AppState } from './types';
import { AIService } from './services/aiService';
import { cn, fileToBase64 } from './utils';

const TRIAL_DURATION_MS = 20 * 60 * 1000; // 20 minutes

export default function App() {
  const [state, setState] = useState<AppState>(() => {
    const apiKey = localStorage.getItem('pixelai_api_key');
    const isPaid = localStorage.getItem('pixelai_is_paid') === 'true';
    let trialStartedAt = localStorage.getItem('pixelai_trial_start');
    
    if (!trialStartedAt) {
      trialStartedAt = Date.now().toString();
      localStorage.setItem('pixelai_trial_start', trialStartedAt);
    }

    return {
      apiKey,
      trialStartedAt: parseInt(trialStartedAt),
      isPaid,
      referenceImage: null,
      generatedImage: null,
      selectedEffect: EFFECTS_LIBRARY[0],
      isGenerating: false,
      error: null,
    };
  });

  const [trialTimeLeft, setTrialTimeLeft] = useState<number>(0);

  const [modals, setModals] = useState<{
    settings: boolean;
    payment: boolean;
    static: 'about' | 'privacy' | 'contact' | null;
  }>({
    settings: false,
    payment: false,
    static: null,
  });

  const aiService = useRef<AIService | null>(null);

  useEffect(() => {
    aiService.current = new AIService(state.apiKey);
  }, [state.apiKey]);

  useEffect(() => {
    const timer = setInterval(() => {
      if (state.trialStartedAt) {
        const elapsed = Date.now() - state.trialStartedAt;
        const remaining = Math.max(0, Math.floor((TRIAL_DURATION_MS - elapsed) / 1000));
        setTrialTimeLeft(remaining);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [state.trialStartedAt]);

  const isTrialExpired = useCallback(() => {
    if (state.isPaid) return false;
    if (!state.trialStartedAt) return true;
    return (Date.now() - state.trialStartedAt) > TRIAL_DURATION_MS;
  }, [state.isPaid, state.trialStartedAt]);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const base64 = await fileToBase64(acceptedFiles[0]);
      setState(prev => ({ ...prev, referenceImage: base64, error: null }));
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': ['.png', '.jpg', '.jpeg', '.webp'] },
    multiple: false,
  } as any);

  const handleGenerate = async () => {
    if (!state.apiKey) {
      setModals(prev => ({ ...prev, settings: true }));
      return;
    }

    if (isTrialExpired()) {
      setModals(prev => ({ ...prev, payment: true }));
      return;
    }

    if (!state.referenceImage || !state.selectedEffect) return;

    setState(prev => ({ ...prev, isGenerating: true, error: null }));

    try {
      const result = await aiService.current!.generateImage(
        state.referenceImage,
        state.selectedEffect
      );
      setState(prev => ({ ...prev, generatedImage: result, isGenerating: false }));
    } catch (err: any) {
      setState(prev => ({ ...prev, error: err.message, isGenerating: false }));
    }
  };

  const saveApiKey = (key: string) => {
    localStorage.setItem('pixelai_api_key', key);
    setState(prev => ({ ...prev, apiKey: key }));
  };

  const handlePayment = () => {
    localStorage.setItem('pixelai_is_paid', 'true');
    setState(prev => ({ ...prev, isPaid: true }));
    setModals(prev => ({ ...prev, payment: false }));
  };

  const downloadImage = () => {
    if (!state.generatedImage) return;
    const link = document.createElement('a');
    link.href = state.generatedImage;
    link.download = `pixelai-${state.selectedEffect?.id}-${Date.now()}.png`;
    link.click();
  };

  return (
    <div className="min-h-screen bg-white text-black font-sans flex flex-col">
      <Header 
        isPaid={state.isPaid} 
        trialTimeLeft={trialTimeLeft}
        onOpenSettings={() => setModals(m => ({ ...m, settings: true }))}
        onOpenPayment={() => setModals(m => ({ ...m, payment: true }))}
      />

      <main className="flex-grow pt-24 pb-12 px-4 max-w-6xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Input & Preview */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-zinc-50 rounded-[2.5rem] p-6 md:p-8 border border-black/5 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <ImageIcon size={20} />
                  Studio Canvas
                </h2>
                {state.referenceImage && (
                  <button 
                    onClick={() => setState(prev => ({ ...prev, referenceImage: null, generatedImage: null }))}
                    className="text-xs font-bold text-black/40 hover:text-black transition-colors"
                  >
                    Clear All
                  </button>
                )}
              </div>

              <div className="aspect-square relative rounded-3xl overflow-hidden bg-zinc-200 border-2 border-dashed border-black/10 group">
                {!state.referenceImage ? (
                  <div 
                    {...getRootProps()} 
                    className={cn(
                      "absolute inset-0 flex flex-col items-center justify-center cursor-pointer transition-all",
                      isDragActive ? "bg-black/5" : "hover:bg-black/5"
                    )}
                  >
                    <input {...getInputProps()} />
                    <div className="w-16 h-16 bg-white rounded-2xl shadow-md flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <Upload className="text-black/40" />
                    </div>
                    <p className="font-bold text-black/60">Drop your photo here</p>
                    <p className="text-xs text-black/30 mt-1">or click to browse files</p>
                  </div>
                ) : (
                  <div className="absolute inset-0 flex flex-col md:flex-row">
                    <div className="relative flex-1 h-full">
                      <img 
                        src={state.referenceImage} 
                        alt="Original" 
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">
                        Original
                      </div>
                    </div>
                    
                    <div className="relative flex-1 h-full bg-zinc-100 border-t md:border-t-0 md:border-l border-black/10 flex items-center justify-center overflow-hidden">
                      {state.isGenerating ? (
                        <div className="flex flex-col items-center gap-4">
                          <RefreshCw className="animate-spin text-black/20" size={40} />
                          <p className="text-xs font-bold text-black/40 animate-pulse">Generating Magic...</p>
                        </div>
                      ) : state.generatedImage ? (
                        <>
                          <img 
                            src={state.generatedImage} 
                            alt="Generated" 
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute top-4 left-4 bg-amber-400 text-black px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider shadow-sm">
                            PixelAi Art
                          </div>
                        </>
                      ) : (
                        <div className="flex flex-col items-center gap-2 text-black/20">
                          <Sparkles size={40} />
                          <p className="text-xs font-bold">Ready to Create</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {state.error && (
                <div className="mt-4 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-start gap-3 text-red-600">
                  <AlertCircle size={18} className="mt-0.5 flex-shrink-0" />
                  <p className="text-xs font-medium leading-relaxed">{state.error}</p>
                </div>
              )}

              <div className="mt-8 flex gap-3">
                <button 
                  disabled={!state.referenceImage || state.isGenerating}
                  onClick={handleGenerate}
                  className={cn(
                    "flex-1 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg",
                    !state.referenceImage || state.isGenerating 
                      ? "bg-zinc-100 text-black/20 shadow-none" 
                      : "bg-black text-white hover:bg-zinc-800 shadow-black/10"
                  )}
                >
                  {state.isGenerating ? (
                    <RefreshCw className="animate-spin" size={20} />
                  ) : (
                    <Sparkles size={20} />
                  )}
                  {state.generatedImage ? "Regenerate" : "Create AI Art"}
                </button>

                {state.generatedImage && (
                  <button 
                    onClick={downloadImage}
                    className="p-4 bg-zinc-100 hover:bg-zinc-200 rounded-2xl transition-colors"
                  >
                    <Download size={20} />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Effects Library */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-[2.5rem] p-6 md:p-8 border border-black/5 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Sparkles size={20} className="text-amber-500" />
                  Artistic Effects
                </h2>
                <span className="text-[10px] font-bold bg-zinc-100 px-2 py-1 rounded-md text-black/40">
                  {EFFECTS_LIBRARY.length} STYLES
                </span>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-2 gap-4 md:gap-6">
                {EFFECTS_LIBRARY.map((effect) => (
                  <EffectCard 
                    key={effect.id}
                    effect={effect}
                    isSelected={state.selectedEffect?.id === effect.id}
                    onSelect={(e) => setState(prev => ({ ...prev, selectedEffect: e }))}
                    isPro={state.isPaid}
                  />
                ))}
              </div>

              <div className="mt-8 p-4 bg-zinc-50 rounded-2xl border border-black/5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center text-white">
                    <History size={16} />
                  </div>
                  <h4 className="text-sm font-bold">Identity Lock Active</h4>
                </div>
                <p className="text-[11px] text-black/50 leading-relaxed">
                  Our AI engine is currently configured to preserve your unique facial features and age while applying the selected style.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer onOpenModal={(type) => setModals(m => ({ ...m, static: type }))} />

      {/* Modals */}
      <SettingsModal 
        isOpen={modals.settings} 
        onClose={() => setModals(m => ({ ...m, settings: false }))}
        apiKey={state.apiKey || ''}
        onSave={saveApiKey}
      />
      
      <PaymentModal 
        isOpen={modals.payment} 
        onClose={() => setModals(m => ({ ...m, payment: false }))}
        onPay={handlePayment}
      />

      <StaticModal 
        isOpen={!!modals.static}
        onClose={() => setModals(m => ({ ...m, static: null }))}
        type={modals.static}
      />
    </div>
  );
}
