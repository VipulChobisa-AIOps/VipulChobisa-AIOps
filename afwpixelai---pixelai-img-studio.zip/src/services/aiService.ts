import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Effect, PROMPT_TEMPLATES } from "../types";

export class AIService {
  private ai: GoogleGenAI | null = null;

  constructor(apiKey: string | null) {
    if (apiKey) {
      this.ai = new GoogleGenAI({ apiKey });
    }
  }

  async generateImage(
    referenceImageBase64: string,
    effect: Effect
  ): Promise<string> {
    if (!this.ai) {
      throw new Error("API Key not configured");
    }

    const prompt = `${PROMPT_TEMPLATES.identity} ${PROMPT_TEMPLATES.lens} Apply the following artistic effect: ${effect.desc}`;

    // Extract base64 data and mime type
    const mimeType = referenceImageBase64.match(/data:([^;]+);/)?.[1] || "image/png";
    const base64Data = referenceImageBase64.split(",")[1] || referenceImageBase64;

    const modelsToTry = ["gemini-2.0-flash", "gemini-2.5-flash-image", "gemini-flash-latest"];
    let lastError = null;

    for (const modelName of modelsToTry) {
      try {
        const response = await this.ai.models.generateContent({
          model: modelName,
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType,
                  data: base64Data,
                },
              },
              {
                text: prompt,
              },
            ],
          },
          config: {
            imageConfig: {
              aspectRatio: "1:1",
            },
          },
        });

        let imageUrl: string | null = null;

        for (const part of response.candidates?.[0]?.content?.parts || []) {
          if (part.inlineData) {
            imageUrl = `data:image/png;base64,${part.inlineData.data}`;
            break;
          }
        }

        if (imageUrl) {
          return imageUrl;
        }
      } catch (error: any) {
        console.warn(`Model ${modelName} failed:`, error);
        lastError = error;
        // Continue to next model
      }
    }

    throw new Error(lastError?.message || "Failed to generate image with available models");
  }
}
