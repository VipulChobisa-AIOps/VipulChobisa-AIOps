/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Effect {
  id: string;
  name: string;
  desc: string;
  previewUrl: string;
  isPremium: boolean;
}

export interface AppState {
  apiKey: string | null;
  trialStartedAt: number | null; // Timestamp
  isPaid: boolean;
  referenceImage: string | null; // Base64
  generatedImage: string | null; // Base64
  selectedEffect: Effect | null;
  isGenerating: boolean;
  error: string | null;
}

export const EFFECTS_LIBRARY: Effect[] = [
  {
    id: 'cyberpunk',
    name: 'Cyberpunk',
    desc: 'Cyberpunk style with neon lights, futuristic city background, high contrast, cinematic lighting, 8k resolution.',
    previewUrl: 'https://picsum.photos/seed/cyberpunk/400/400',
    isPremium: false,
  },
  {
    id: 'oil-painting',
    name: 'Oil Painting',
    desc: 'Classic oil painting style, visible brushstrokes, rich textures, warm lighting, museum quality masterpiece.',
    previewUrl: 'https://picsum.photos/seed/oil/400/400',
    isPremium: false,
  },
  {
    id: 'anime',
    name: 'Anime Studio',
    desc: 'High-quality anime style, vibrant colors, clean lines, expressive features, Studio Ghibli inspired background.',
    previewUrl: 'https://picsum.photos/seed/anime/400/400',
    isPremium: false,
  },
  {
    id: 'sketch',
    name: 'Pencil Sketch',
    desc: 'Detailed pencil sketch, graphite texture, cross-hatching, artistic shading, white paper background.',
    previewUrl: 'https://picsum.photos/seed/sketch/400/400',
    isPremium: false,
  },
  {
    id: 'viking',
    name: 'Viking Warrior',
    desc: 'Viking warrior aesthetic, fur armor, war paint, snowy mountain background, epic cinematic atmosphere.',
    previewUrl: 'https://picsum.photos/seed/viking/400/400',
    isPremium: false,
  },
  {
    id: 'steampunk',
    name: 'Steampunk',
    desc: 'Steampunk aesthetic, brass gears, leather goggles, Victorian era clothing, sepia tones, intricate machinery.',
    previewUrl: 'https://picsum.photos/seed/steampunk/400/400',
    isPremium: false,
  },
  {
    id: 'watercolor',
    name: 'Watercolor',
    desc: 'Soft watercolor painting, bleeding colors, paper texture, delicate washes, artistic and ethereal.',
    previewUrl: 'https://picsum.photos/seed/watercolor/400/400',
    isPremium: false,
  },
  {
    id: 'superhero',
    name: 'Superhero',
    desc: 'Comic book superhero style, cinematic suit, heroic pose, dramatic lighting, urban city background.',
    previewUrl: 'https://picsum.photos/seed/superhero/400/400',
    isPremium: false,
  },
  {
    id: 'vintage-film',
    name: 'Vintage Film',
    desc: '90s vintage film aesthetic, heavy grain, light leaks, faded colors, nostalgic atmosphere.',
    previewUrl: 'https://picsum.photos/seed/vintage/400/400',
    isPremium: false,
  },
  {
    id: 'golden-hour',
    name: 'Golden Hour',
    desc: 'Warm golden hour lighting, soft sun rays, long shadows, glowing skin, sunset atmosphere.',
    previewUrl: 'https://picsum.photos/seed/golden/400/400',
    isPremium: false,
  },
  {
    id: 'glitch-art',
    name: 'Glitch Art',
    desc: 'Digital glitch art, RGB color shift, pixel sorting, distortion, futuristic tech aesthetic.',
    previewUrl: 'https://picsum.photos/seed/glitch/400/400',
    isPremium: false,
  },
  {
    id: 'pop-art',
    name: 'Pop Art',
    desc: 'Andy Warhol style pop art, bold saturated colors, halftone dots, high contrast, comic book aesthetic.',
    previewUrl: 'https://picsum.photos/seed/pop/400/400',
    isPremium: false,
  },
  {
    id: 'neon-nights',
    name: 'Neon Nights',
    desc: 'Vibrant neon glow, electric blue and magenta lighting, dark city street background, rainy reflections.',
    previewUrl: 'https://picsum.photos/seed/neon/400/400',
    isPremium: false,
  },
  {
    id: 'pastel-dream',
    name: 'Pastel Dream',
    desc: 'Soft pastel colors, dreamy and ethereal atmosphere, light clouds, gentle lighting, whimsical feel.',
    previewUrl: 'https://picsum.photos/seed/pastel/400/400',
    isPremium: false,
  },
  {
    id: 'double-exposure',
    name: 'Double Exposure',
    desc: 'Artistic double exposure, blending the subject with a beautiful forest landscape, ethereal and creative.',
    previewUrl: 'https://picsum.photos/seed/double/400/400',
    isPremium: false,
  },
  {
    id: 'gothic-horror',
    name: 'Gothic Horror',
    desc: 'Dark gothic horror aesthetic, moody lighting, high contrast shadows, Victorian mansion background.',
    previewUrl: 'https://picsum.photos/seed/gothic/400/400',
    isPremium: false,
  },
  {
    id: 'synthwave',
    name: 'Synthwave',
    desc: '80s synthwave retro aesthetic, purple and pink gradients, wireframe sun, futuristic grid background.',
    previewUrl: 'https://picsum.photos/seed/synth/400/400',
    isPremium: false,
  },
  {
    id: 'minimalist',
    name: 'Minimalist',
    desc: 'Clean minimalist style, simple color palette, sharp lines, professional studio background, elegant.',
    previewUrl: 'https://picsum.photos/seed/minimal/400/400',
    isPremium: false,
  },
  {
    id: 'renaissance',
    name: 'Renaissance',
    desc: 'Classic Renaissance portrait painting, dramatic chiaroscuro lighting, rich textures, museum quality.',
    previewUrl: 'https://picsum.photos/seed/renaissance/400/400',
    isPremium: false,
  },
  {
    id: 'comic-book',
    name: 'Comic Book',
    desc: 'Modern comic book style, bold ink outlines, action lines, vibrant colors, superhero aesthetic.',
    previewUrl: 'https://picsum.photos/seed/comic/400/400',
    isPremium: false,
  },
  {
    id: 'vaporwave',
    name: 'Vaporwave',
    desc: 'Surreal vaporwave aesthetic, 90s digital art, Roman statues, tropical palms, glitchy pink sky.',
    previewUrl: 'https://picsum.photos/seed/vapor/400/400',
    isPremium: false,
  },
  {
    id: 'fantasy-forest',
    name: 'Fantasy Forest',
    desc: 'Ethereal fantasy forest background, magical glowing plants, soft lighting, fairy tale atmosphere.',
    previewUrl: 'https://picsum.photos/seed/fantasy/400/400',
    isPremium: false,
  },
  {
    id: 'underwater',
    name: 'Underwater',
    desc: 'Underwater aesthetic, deep blue tones, bubbles, distorted light rays, coral reef background.',
    previewUrl: 'https://picsum.photos/seed/underwater/400/400',
    isPremium: false,
  },
  {
    id: 'space-explorer',
    name: 'Space Explorer',
    desc: 'Astronaut suit aesthetic, nebula and galaxy background, cinematic space lighting, epic atmosphere.',
    previewUrl: 'https://picsum.photos/seed/space/400/400',
    isPremium: false,
  },
  {
    id: 'graffiti',
    name: 'Graffiti Art',
    desc: 'Street art graffiti style, spray paint textures, vibrant colors, urban brick wall background.',
    previewUrl: 'https://picsum.photos/seed/graffiti/400/400',
    isPremium: false,
  },
  {
    id: 'mosaic',
    name: 'Mosaic',
    desc: 'Intricate mosaic tile art, vibrant colors, geometric patterns, artistic and textured.',
    previewUrl: 'https://picsum.photos/seed/mosaic/400/400',
    isPremium: false,
  },
  {
    id: 'charcoal',
    name: 'Charcoal',
    desc: 'Rough charcoal sketch, deep blacks, textured paper, artistic shading, expressive strokes.',
    previewUrl: 'https://picsum.photos/seed/charcoal/400/400',
    isPremium: false,
  },
  {
    id: 'paper-cutout',
    name: 'Paper Cutout',
    desc: 'Layered paper cutout art, 3D depth effect, vibrant colors, whimsical and creative.',
    previewUrl: 'https://picsum.photos/seed/paper/400/400',
    isPremium: false,
  },
  {
    id: 'infrared',
    name: 'Infrared',
    desc: 'Surreal infrared photography, pink and white foliage, deep blue sky, ethereal atmosphere.',
    previewUrl: 'https://picsum.photos/seed/infrared/400/400',
    isPremium: false,
  },
  {
    id: 'low-poly',
    name: 'Low Poly',
    desc: 'Geometric low poly art, faceted surfaces, vibrant colors, modern digital aesthetic.',
    previewUrl: 'https://picsum.photos/seed/poly/400/400',
    isPremium: false,
  }
];

export const PROMPT_TEMPLATES = {
  identity: "CRITICAL: Maintain the exact facial features, age, gender, and identity of the person in the reference image. The subject must be clearly recognizable as the same person.",
  lens: "Portrait photography, 85mm lens, f/1.8, sharp focus on eyes, professional studio lighting, highly detailed skin texture.",
};
