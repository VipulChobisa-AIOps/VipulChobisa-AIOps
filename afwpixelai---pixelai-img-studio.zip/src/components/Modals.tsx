import React, { useState, useEffect } from 'react';
import { X, Key, Save, AlertCircle, Crown, Info, Mail, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ scale: 0.95, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 20 }}
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden"
      >
        <div className="px-6 py-4 border-b border-black/5 flex items-center justify-between">
          <h3 className="font-bold text-lg">{title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-black/5 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>
        <div className="p-6">
          {children}
        </div>
      </motion.div>
    </div>
  );
};

export const SettingsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  apiKey: string;
  onSave: (key: string) => void;
}> = ({ isOpen, onClose, apiKey, onSave }) => {
  const [tempKey, setTempKey] = useState(apiKey);

  useEffect(() => {
    setTempKey(apiKey);
  }, [apiKey]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Settings">
      <div className="space-y-6">
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-black/40 flex items-center gap-2">
            <Key size={14} />
            Gemini API Key
          </label>
          <input 
            type="password"
            value={tempKey}
            onChange={(e) => setTempKey(e.target.value)}
            placeholder="Enter your Google AI API Key"
            className="w-full px-4 py-3 bg-zinc-100 rounded-xl border border-transparent focus:border-black/10 focus:bg-white outline-none transition-all text-sm"
          />
          <p className="text-[10px] text-black/40 leading-relaxed">
            Your API key is stored locally on your device and never sent to our servers. You can get one for free at <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-black underline font-medium">Google AI Studio</a>.
          </p>
        </div>

        <button 
          onClick={() => {
            onSave(tempKey);
            onClose();
          }}
          className="w-full bg-black text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-zinc-800 transition-colors"
        >
          <Save size={18} />
          Save Changes
        </button>
      </div>
    </Modal>
  );
};

export const PaymentModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onPay: () => void;
}> = ({ isOpen, onClose, onPay }) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Trial Expired">
      <div className="space-y-6 text-center">
        <div className="w-20 h-20 bg-amber-100 rounded-3xl flex items-center justify-center mx-auto mb-2">
          <AlertCircle className="text-amber-500" size={40} />
        </div>
        
        <div className="space-y-2">
          <h4 className="text-2xl font-bold">Your Free Trial has Ended</h4>
          <p className="text-sm text-black/50">You've enjoyed 20 minutes of unlimited AI art. Upgrade now to continue creating stunning images.</p>
        </div>

        <div className="space-y-3 text-left bg-zinc-50 p-4 rounded-2xl">
          {[
            "Unlimited AI generations",
            "Access to all 30+ artistic effects",
            "Priority generation speed",
            "High-resolution image output",
            "No watermarks on shared images"
          ].map((feature, i) => (
            <div key={i} className="flex items-center gap-3 text-sm">
              <div className="w-5 h-5 bg-black text-white rounded-full flex items-center justify-center flex-shrink-0">
                <Check size={12} />
              </div>
              {feature}
            </div>
          ))}
        </div>

        <button 
          onClick={onPay}
          className="w-full bg-black text-white py-4 rounded-2xl font-bold text-lg hover:bg-zinc-800 transition-colors shadow-lg"
        >
          Unlock Full Access - $4.99
        </button>
        
        <p className="text-[10px] text-black/30">
          One-time payment or monthly subscription options available.
        </p>
      </div>
    </Modal>
  );
};

const Check = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
);

export const StaticModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  type: 'about' | 'privacy' | 'contact' | null;
}> = ({ isOpen, onClose, type }) => {
  const content = {
    about: {
      title: "About PixelAi",
      icon: <Info className="text-blue-500" />,
      text: "afwPixelAi is a state-of-the-art AI image studio designed for creators who want to explore artistic styles without losing their identity. Our proprietary 'Identity Lock' technology ensures that facial features remain consistent across all transformations."
    },
    privacy: {
      title: "Privacy Policy",
      icon: <Shield className="text-emerald-500" />,
      text: "Your privacy is our priority. We do not store your photos or API keys on our servers. All image processing happens directly between your device and Google's AI infrastructure. Your API key is stored securely in your device's local storage."
    },
    contact: {
      title: "Contact Us",
      icon: <Mail className="text-purple-500" />,
      text: "Have questions or feedback? We'd love to hear from you. Reach out to our support team at support@askforwrite.com or follow us on social media for the latest updates and featured art."
    }
  };

  if (!type) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={content[type].title}>
      <div className="space-y-4">
        <div className="w-12 h-12 bg-zinc-100 rounded-2xl flex items-center justify-center">
          {content[type].icon}
        </div>
        <p className="text-sm text-black/70 leading-relaxed">
          {content[type].text}
        </p>
      </div>
    </Modal>
  );
};
