import React from 'react';
import { Crown, Check } from 'lucide-react';
import { Effect } from '../types';
import { cn } from '../utils';

interface EffectCardProps {
  effect: Effect;
  isSelected: boolean;
  onSelect: (effect: Effect) => void;
  isPro: boolean;
}

export const EffectCard: React.FC<EffectCardProps> = ({ effect, isSelected, onSelect, isPro }) => {
  const isLocked = effect.isPremium && !isPro;

  return (
    <button
      onClick={() => onSelect(effect)}
      className={cn(
        "relative group flex flex-col items-center gap-2 transition-all duration-300",
        isSelected ? "scale-105" : "hover:scale-102"
      )}
    >
      <div className={cn(
        "relative w-24 h-24 md:w-32 md:h-32 rounded-2xl overflow-hidden border-2 transition-all",
        isSelected ? "border-black shadow-lg" : "border-transparent shadow-sm group-hover:border-black/20"
      )}>
        <img 
          src={effect.previewUrl} 
          alt={effect.name}
          className={cn(
            "w-full h-full object-cover transition-transform duration-500",
            isSelected ? "scale-110" : "group-hover:scale-110",
            isLocked && "grayscale opacity-80"
          )}
          referrerPolicy="no-referrer"
        />
        
        {isLocked && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <Crown className="text-amber-400" size={24} />
          </div>
        )}

        {isSelected && (
          <div className="absolute top-2 right-2 bg-black text-white rounded-full p-1">
            <Check size={12} />
          </div>
        )}
      </div>
      
      <span className={cn(
        "text-xs font-bold tracking-tight",
        isSelected ? "text-black" : "text-black/60"
      )}>
        {effect.name}
      </span>
    </button>
  );
};
