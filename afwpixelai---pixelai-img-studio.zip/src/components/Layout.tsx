import React from 'react';
import { Settings, User, Crown, Info, Mail, Shield } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenPayment: () => void;
  isPaid: boolean;
  trialTimeLeft: number; // in seconds
}

export const Header: React.FC<HeaderProps> = ({ onOpenSettings, onOpenPayment, isPaid, trialTimeLeft }) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(Math.max(0, seconds) / 60);
    const secs = Math.max(0, seconds) % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-black/5 px-4 h-16 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="w-10 h-10 bg-black rounded-xl flex items-center justify-center">
          <span className="text-white font-bold text-xl">P</span>
        </div>
        <div>
          <h1 className="font-bold text-lg leading-tight">PixelAi</h1>
          <p className="text-[10px] uppercase tracking-widest text-black/40 font-semibold">Img Studio</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {!isPaid && (
          <div className="hidden sm:flex items-center gap-2 bg-zinc-100 px-3 py-1.5 rounded-full text-[10px] font-bold text-black/40">
            TRIAL: {formatTime(trialTimeLeft)}
          </div>
        )}
        {!isPaid && trialTimeLeft <= 0 && (
          <button 
            onClick={onOpenPayment}
            className="flex items-center gap-2 bg-amber-400 hover:bg-amber-500 text-black px-3 py-1.5 rounded-full text-xs font-bold transition-colors shadow-sm"
          >
            <Crown size={14} />
            UNLOCK FULL
          </button>
        )}
        {isPaid && (
          <div className="flex items-center gap-2 bg-emerald-50 text-emerald-600 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
            <Crown size={12} />
            Full Access
          </div>
        )}
        <button 
          onClick={onOpenSettings}
          className="p-2 hover:bg-black/5 rounded-full transition-colors text-black/60"
        >
          <Settings size={20} />
        </button>
      </div>
    </header>
  );
};

interface FooterProps {
  onOpenModal: (type: 'about' | 'privacy' | 'contact') => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenModal }) => {
  return (
    <footer className="bg-zinc-50 border-t border-black/5 py-12 px-6 mt-auto">
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">P</span>
              </div>
              <span className="font-bold">afwPixelAi</span>
            </div>
            <p className="text-sm text-black/50 max-w-xs">
              Transform your photos into stunning AI art while keeping your identity locked. The ultimate mobile-first AI image studio.
            </p>
          </div>
          
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-black/30">Company</h4>
            <button onClick={() => onOpenModal('about')} className="text-sm text-black/60 hover:text-black text-left">About Us</button>
            <button onClick={() => onOpenModal('contact')} className="text-sm text-black/60 hover:text-black text-left">Contact</button>
          </div>

          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-black/30">Legal</h4>
            <button onClick={() => onOpenModal('privacy')} className="text-sm text-black/60 hover:text-black text-left">Privacy Policy</button>
            <button className="text-sm text-black/60 hover:text-black text-left">Terms of Service</button>
          </div>
        </div>
        
        <div className="pt-8 border-t border-black/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-black/40">© 2026 AskForWrite. All rights reserved.</p>
          <div className="flex gap-6">
             {/* Social icons could go here */}
          </div>
        </div>
      </div>
    </footer>
  );
};
